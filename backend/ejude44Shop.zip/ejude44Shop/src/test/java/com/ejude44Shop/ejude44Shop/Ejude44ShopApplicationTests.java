package com.ejude44Shop.ejude44Shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejude44ShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
