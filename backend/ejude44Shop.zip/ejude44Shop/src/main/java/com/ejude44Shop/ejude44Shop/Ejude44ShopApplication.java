package com.ejude44Shop.ejude44Shop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejude44ShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejude44ShopApplication.class, args);
	}

}
